<?php
get_header();

echo $post->post_content;

get_footer(); 

?>